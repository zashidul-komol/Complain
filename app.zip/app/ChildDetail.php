<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChildDetail extends Model
{
    protected $fillable = ['user_id',	'child_name', 'child_occupation',	'child_gendar',	'child_DOB',	'child_education'];

    
}


