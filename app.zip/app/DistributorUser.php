<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DistributorUser extends Model {
	public $timestamps = false;
	protected $guarded = array('id');
}
