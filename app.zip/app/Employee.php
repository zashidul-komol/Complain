<?php

namespace App;

use App\Department;
use App\Designation;
use App\OfficeLocation;
use App\FamilyDetail;
use App\EmployeeEducation;

use App\SiblingDetail;
use App\CertificationCourse;
use App\ChildDetail;
use App\JobExperiance;
use App\ProfDegree;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = ['polar_id',	'name',	'dept_id',	'desig_id',	'office_loc_id','region_id',	'mobile', 'hiredate', 'birthdate', 'hobby',	'grade', 'email',	'bloodgroup',	'gender',	'job_status',	'maritial_status',	'present_address',	'permanent_address',	'status'];


    public function designation() {
        return $this->belongsTo(Designation::class,'desig_id');
    }

 	public function department() {
        return $this->belongsTo(Department::class,'dept_id');
    }

    public function office_location() {
        return $this->belongsTo(OfficeLocation::class);
    }

    public function family_details() {
        return $this->hasMany(FamilyDetail::class);
    }

    public function employee_educations() {
        return $this->hasMany(EmployeeEducation::class);
    }
    public function certification_courses() {
        return $this->hasMany(CertificationCourse::class);
    }
    public function child_details() {
        return $this->hasMany(ChildDetail::class);
    }
    public function job_experiances() {
        return $this->hasMany(JobExperiance::class);
    }
    public function prof_degrees() {
        return $this->hasMany(ProfDegree::class);
    }
    public function sibling_details() {
        return $this->hasMany(SiblingDetail::class);
    }

}



