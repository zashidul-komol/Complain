<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Department;
use App\Designation;
use App\OfficeLocation;
use App\Region;

use Illuminate\Http\Request;

class EmployeesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
        $employees = Employee::with([
            'designation' => function ($q) {
                return $q->select('id', 'title');
            },
            'department'=>function($q){
                return $q->select('id', 'name');
            },
            'family_details' => function ($q) {
                return $q->select('*');
            },
            'employee_educations'=>function($q){
                return $q->select('*');
            },
            'child_details'=>function($q){
                return $q->select('*');
            },
            'certification_courses'=>function($q){
                return $q->select('*');
            },
            'job_experiances'=>function($q){
                return $q->select('*');
            },
            'office_location'=>function($q){
                return $q->select('*');
            },
            'prof_degrees'=>function($q){
                return $q->select('*');
            },
        ])
        ->get();
        //dd($employees->toArray());
        //$departments = Department::with(['id' => function ($q) {
           // return $q->select('name', 'id');
       // }])
        //    ->whereIn('dept_id', $this->idemployees())
        //    ->get();
        //dd($employees->toArray());

        //->where('id',7)
        //->get();
        //dd ($employee->polar_id);
        

        return view('employees.index', compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       // dd(str_plural('child'));
        $departments = Department::pluck('name','id');
        $designations = Designation::pluck('title','id');
        $officelocations = OfficeLocation::pluck('name','id');
        $regions = Region::pluck('name','id');
        //dd($officelocations->toArray());
        return view('employees.create', compact('departments','designations','officelocations','regions'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        //dd($data);
        $request->validate([
            'name' => 'required|unique:employees',
        ]);

        $employees = Employee::create($data);
        if ($employees) {
            $message = "You have successfully created";
            return redirect()->route('employees.create', [])
                ->with('flash_success', $message);

        } else {
            $message = "Something wrong!! Please try again";
            return redirect()->route('employees.create', [])
                ->with('flash_danger', $message);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function view($id)
    {
        return view('employees.view');
    }


    public function edit($id)
    {
        $employees = Employee::findOrFail($id);
        $departments = Department::pluck('name','id');
        $designations = Designation::pluck('title','id');
        $officelocations = OfficeLocation::pluck('name','id');
        $regions = Region::pluck('name','id');
        //dd($officelocations->toArray());
        //return view('employees.create', compact('departments','designations','officelocations','regions'));
        return view('employees.edit', compact('employees','departments','designations','officelocations','regions'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->except('_method', '_token');
        $request->validate([
            'name' => 'required|unique:employees,name,' . $id,
            'status' => 'required',
        ]);

        $employees = Employee::where('id', $id)->update($data);
        if ($employees) {
            $message = "You have successfully updated";
            return redirect()->route('employees.index', [])
                ->with('flash_success', $message);

        } else {
            $message = "Nothing changed!! Please try again";
            return redirect()->route('employees.index', [])
                ->with('flash_warning', $message);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employees = Employee::destroy($id);
        if ($employees) {
            $message = "You have successfully deleted";
            return redirect()->route('employees.index', [])
                ->with('flash_success', $message);
        } else {
            $message = "Something wrong!! Please try again";
            return redirect()->route('employees.index', [])
                ->with('flash_danger', $message);
        }
    }

    public function download() {
        return (new EmployeeExport())->download('employee.xlsx');
    }
}
