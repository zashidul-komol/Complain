<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmsPromotional extends Model{
    protected $guarded = array('id');
    const UPDATED_AT=null;
}
