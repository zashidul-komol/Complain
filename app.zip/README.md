# composer update
# php artisan storage:link
# install npm
# run npm dev/ run npm production

If template color need to change then uncomment the line

'@import "theme-colors/theme-colors/green-dark-theme";' 
				or 
any one from file 'resources/assets/sass/settings/theme-colors.scss'.
                            
thats it!!!